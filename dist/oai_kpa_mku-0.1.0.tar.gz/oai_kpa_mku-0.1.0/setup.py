# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['oai_kpa_mku']
setup_kwargs = {
    'name': 'oai-kpa-mku',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'snbnv',
    'author_email': 'snbnv@yandex.ru',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
