# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['oai_kpa_mku']

package_data = \
{'': ['*'], 'oai_kpa_mku': ['cfg/*', 'log/2021_09_14 oai_kpa_mku/*']}

install_requires = \
['PyQt5>=5.15,<6.0',
 'oai_modbus @ git+https://github.com/CrinitusFeles/OAI_Modbus.git@master']

setup_kwargs = {
    'name': 'oai-kpa-mku',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'snbnv',
    'author_email': 'snbnv@yandex.ru',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
